#!/usr/bin/bash
sudo -s docker pull hscleandro/funn-mg:1.13
mkdir -p output_funn

COUNT=$(sudo docker volume ls -f name=funndata | grep "funndata" | wc -l)
if [ $COUNT = 0 ];
then
  sudo -s docker volume create --name funndata
fi

COUNT=$(sudo docker ps -a -f name=funn | grep "funn" | wc -l)
if [ $COUNT = 0 ];
then
  sudo docker run -itd --name funn -v funndata:/data/db -v $(pwd)/output_funn:/home/output_funn/ -v /tmp/.X11-unix:/tmp/.X11-unix -e DISPLAY=unix$DISPLAY --device /dev/dri -p 3838:3838 hscleandro/funn-mg:1.13
fi

sleep 10

sudo docker start funn
sudo docker exec -itd funn bin/bash -c "cd /srv/shiny-server/ && sudo shiny-server"
sudo docker exec -itd funn bin/bash -c "sudo mongod"


sudo docker inspect funn > f.txt
IP=$(grep -o '"IPAddress":\s"[0-9]*.[0-9]*.[0-9]*.[0-9]"' f.txt | head -1)
echo $IP | sed -e "s/\"IPAddress\":\s//g" > f.txt
IP=$(cat f.txt | sed -e "s/\"//g")
rm f.txt

flag_net=false
flag_browser=false

filename="funn.conf"
while read -r line
do
  name="$line"
  remainder="$name"

  if ! echo $remainder | egrep -q '^ *#'
  then
    echo $remainder" saving!"
  else
    echo $remainder" commented out"
    continue
  fi


  first=$(echo $remainder | cut -f1 -d=)
  second=$(echo $remainder | cut -f2 -d=)

  if [ $first = "project_name" ];
  then
    project_name=$second
  fi
  if [ $first = "sample_name" ];
  then
    sample_name=$second
  fi
  if [ $first = "path_to_protein_file" ];
  then
    path_to_protein_file=$second
    param_file_protein='--prot '${path_to_protein_file##*/}
    sudo docker cp $path_to_protein_file funn:/FUNN-MG/funn-mg-v.13/src
  fi
  if [ $first = "path_to_kaas_file" ];
  then
    path_to_kaas_file=$second
    param_file_kaas='-f '${path_to_kaas_file##*/}
    sudo docker cp $path_to_kaas_file funn:/FUNN-MG/funn-mg-v.13/src
  fi
  if [ $first = "path_to_kaiju_file" ];
  then
    path_to_kaiju_file=$second
    param_file_kaiju='-t '${path_to_kaiju_file##*/}
    sudo docker cp $path_to_kaiju_file funn:/FUNN-MG/funn-mg-v.13/src
  fi
  if [ $first = "display_net" -a $second = "yes" ];
  then
    flag_net=true
  fi
  if [ $first = "open_browser_auto" -a $second = "yes" ];
  then
    flag_browser=true
  fi
  if [ $first = "p_value" -a $second != "" ];
  then
    p_value="--pvalue "$second
  fi
  if [ $first = "global_over" -a $second = "yes" ];
  then
    global="--global"
  fi
  if [ $first = "type_hierarchical" -a $second != "" ];
  then
    type_hierarchical="--type "$second
  fi
  if [ $first = "prot" -a $second = "yes" ];
  then
    prot="--prot"
  fi
done < "$filename"

sudo docker exec -it funn bin/bash -c "cd /FUNN-MG/funn-mg-v.13/src/ && sudo Rscript funn-mg.R $param_file_kaas $param_file_kaiju $param_file_protein -s $sample_name -p $project_name $p_value $global"


if [ $flag_net = true ];
then
  sudo docker exec -d funn bin/bash -c "cd /FUNN-MG/funn-mg-v.13/src/ && Rscript funn-mg.R -s $sample_name -p $project_name --display $type_hierarchical $prot"
fi

if [ $flag_browser = true ];
then
  sensible-browser http://"$IP":3838/view/
fi
echo "Access on the browser: http://$IP:3838/view/"